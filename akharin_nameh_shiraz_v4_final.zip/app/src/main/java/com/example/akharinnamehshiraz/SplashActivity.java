package com.example.akharinnamehshiraz;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.media.*;import android.view.*;import android.widget.*;import java.util.*;
public class SplashActivity extends Activity{
 MediaPlayer music;public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(3,6,11));getWindow().setNavigationBarColor(Color.rgb(3,6,11));
  FrameLayout frame=new FrameLayout(this);ImageView bg=new ImageView(this);bg.setImageResource(getResources().getIdentifier("splash_hero","drawable",getPackageName()));bg.setScaleType(ImageView.ScaleType.CENTER_CROP);frame.addView(bg,new FrameLayout.LayoutParams(-1,-1));SnowView snow=new SnowView(this);frame.addView(snow,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout overlay=UI.col(this);overlay.setGravity(Gravity.CENTER_HORIZONTAL);overlay.setPadding(UI.dp(this,26),0,UI.dp(this,26),0);
  TextView eyebrow=UI.tv(this,"یک روایت ایرانی از عشق، راز و بازگشت",12,UI.GOLD2,true);eyebrow.setGravity(Gravity.CENTER);overlay.addView(eyebrow,new LinearLayout.LayoutParams(-1,-2));
  TextView title=UI.heading(this,"آخرین نامه\nاز شیراز",32);title.setGravity(Gravity.CENTER);title.setLineSpacing(0,1.0f);overlay.addView(title,new LinearLayout.LayoutParams(-1,-2));UI.margin(title,0,UI.dp(this,10),0,0);
  TextView author=UI.tv(this,"اثرِ میلاد شجیراتی",16,UI.CREAM,true);author.setGravity(Gravity.CENTER);overlay.addView(author,new LinearLayout.LayoutParams(-1,-2));
  TextView meta=UI.tv(this,"رمان عاشقانه  •  معمایی  •  اجتماعی",11,UI.MUTED,false);meta.setGravity(Gravity.CENTER);overlay.addView(meta,new LinearLayout.LayoutParams(-1,-2));
  TextView dots=UI.tv(this,"•  •  •",18,UI.GOLD,true);dots.setGravity(Gravity.CENTER);overlay.addView(dots,new LinearLayout.LayoutParams(-1,UI.dp(this,52)));TextView load=UI.tv(this,"فضای مطالعه در حال آماده‌سازی است",11,UI.CREAM,false);load.setGravity(Gravity.CENTER);overlay.addView(load,new LinearLayout.LayoutParams(-1,-2));
  FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);op.topMargin=UI.dp(this,240);frame.addView(overlay,op);
  TextView bottom=UI.tv(this,"نسخه ۴.۰.۰  •  مطالعه آفلاین  •  موسیقی مطالعه",10,UI.MUTED,false);bottom.setGravity(Gravity.CENTER);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,UI.dp(this,54),Gravity.BOTTOM);frame.addView(bottom,bp);setContentView(frame);
  try{music=MediaPlayer.create(this,getResources().getIdentifier("entry_premium","raw",getPackageName()));if(music!=null){music.setLooping(false);music.setVolume(.38f,.38f);music.start();}}catch(Exception ignored){}
  new Handler().postDelayed(()->{release();startActivity(new Intent(this,MainActivity.class));overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);finish();},4200);
 }
 void release(){try{if(music!=null){music.stop();music.release();music=null;}}catch(Exception ignored){}}
 protected void onDestroy(){release();super.onDestroy();}
 static class SnowView extends View{Paint p=new Paint(3);Random r=new Random(17);ArrayList<F> fs=new ArrayList<>();SnowView(Context c){super(c);for(int i=0;i<105;i++)fs.add(new F(r));}protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();for(F f:fs){p.setColor(Color.argb(f.a,245,248,250));c.drawCircle(f.x,f.y,f.s,p);f.y+=f.v;f.x+=Math.sin(f.t)*.28f;f.t+=.012f;if(f.y>h+8){f.y=-8;f.x=r.nextInt(Math.max(1,w));}}postInvalidateDelayed(20);}static class F{float x,y,s,v,t;int a;F(Random r){x=r.nextFloat()*1000;y=r.nextFloat()*2200;s=.7f+r.nextFloat()*2.8f;v=.45f+r.nextFloat()*1.9f;t=r.nextFloat()*6.28f;a=45+r.nextInt(145);}}}
}
