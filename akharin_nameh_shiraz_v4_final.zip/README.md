# آخرین نامه از شیراز — نسخه نهایی 4.0.0

رمان فارسی آفلاین با رابط کاربری RTL، طراحی سینمایی، کاور و آیکون اختصاصی، مطالعه حرفه‌ای، نشانک، ادامه مطالعه، جست‌وجو، کنترل فونت و فاصله خطوط، تایمر تمرکز و موسیقی آرام مخصوص مطالعه.

## مشخصات
- Application ID: `com.example.akharinnamehshiraz`
- Version: `4.0.0`
- Version Code: `4`
- Min SDK: 23
- Target SDK: 35
- Compile SDK: 35
- بدون وابستگی خارجی AndroidX/Material؛ رابط با Java ساخته شده تا ریسک خطای Gradle/AAPT کمتر شود.

## انتشار
برای GitHub Actions فعلی این مخزن، نام فایل ZIP باید دقیقاً `akharin_nameh_shiraz_final_v1.zip` باشد؛ Workflow موجود همین نام را استخراج می‌کند.

کلید امضای Release از Secrets خوانده می‌شود و داخل پروژه قرار ندارد.
