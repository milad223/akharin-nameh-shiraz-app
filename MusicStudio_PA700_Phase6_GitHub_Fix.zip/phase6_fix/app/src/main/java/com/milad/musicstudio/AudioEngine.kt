package com.milad.musicstudio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.milad.musicstudio.korg.SampleData
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class AudioEngine {
    private val sampleRate = 44100
    private var track: AudioTrack? = null
    private val samples = SamplePlayer()

    fun note(midi: Int, durationMs: Int = 420) {
        val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track?.release()
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, sampleRate / 2)).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
        val f = 440.0 * 2.0.pow((midi - 69) / 12.0)
        val n = sampleRate * durationMs / 1000
        val pcm = ShortArray(n)
        for (i in 0 until n) {
            val t=i.toDouble()/sampleRate; val a=minOf(1.0,i/(sampleRate*.008)); val r=exp(-4.5*maxOf(0.0,t-durationMs/1000.0+.18)); val e=a*r
            val x=(sin(2*PI*f*t)+.32*sin(2*PI*2*f*t)+.12*sin(2*PI*3*f*t))*.22*e
            pcm[i]=(x*Short.MAX_VALUE).toInt().coerceIn(-32768,32767).toShort()
        }
        track?.write(pcm,0,pcm.size)
    }
    fun playSample(sample: SampleData) = samples.play(sample)
    fun stop() { runCatching { track?.stop() }; track?.release(); track=null; samples.stop() }
    fun release()=stop()
}
private fun Double.pow(v:Double)=kotlin.math.exp(v*kotlin.math.ln(this))
