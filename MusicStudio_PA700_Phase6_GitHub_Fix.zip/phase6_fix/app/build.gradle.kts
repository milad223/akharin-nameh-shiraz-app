plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace="com.milad.musicstudio"; compileSdk=35
    defaultConfig { applicationId="com.milad.musicstudio"; minSdk=26; targetSdk=35; versionCode=24; versionName="2.4" }
}
