# Music Studio PA700 — Phase 6 (GitHub/Gradle fixed)

This package is a cleaned Android Studio project based on Phase 5.

## Fixes
- Fixed `MainActivity.onCreate()` parameter mismatch that caused compilation failure.
- Removed the duplicated nested project directory from the distributable ZIP.
- Added `.gitignore` for Android/Gradle artifacts.
- Added GitHub Actions CI workflow to build `assembleDebug` with JDK 17 and Gradle 8.9.
- Kept the KMP inspector and experimental PCM path unchanged and clearly labelled as heuristic/experimental.

## Build locally
Use Android Studio or Gradle 8.9 with JDK 17:

    gradle assembleDebug

The project intentionally does not claim complete decoding of proprietary KORG sample compression.
