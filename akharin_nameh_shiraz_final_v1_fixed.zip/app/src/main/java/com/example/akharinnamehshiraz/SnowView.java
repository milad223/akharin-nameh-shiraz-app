package com.example.akharinnamehshiraz;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.*;

public class SnowView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random r = new Random(7);
    private final ArrayList<Flake> flakes = new ArrayList<>();
    public SnowView(Context c) { super(c); p.setColor(Color.WHITE); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    private void init() { if (!flakes.isEmpty()) return; for(int i=0;i<95;i++) flakes.add(new Flake(r.nextFloat(), r.nextFloat(), 1+r.nextFloat()*4, 0.6f+r.nextFloat()*1.8f, r.nextFloat()*6.28f)); }
    @Override protected void onDraw(Canvas c) { super.onDraw(c); init(); float w=getWidth(), h=getHeight(); p.setShadowLayer(5,0,1,0x88FFFFFF); for(Flake f:flakes){ f.y += f.speed/120f; f.x += (float)Math.sin(f.phase + f.y*7)*0.0007f; if(f.y>1.05f) {f.y=-0.04f; f.x=r.nextFloat();} if(f.x<0)f.x=1; if(f.x>1)f.x=0; p.setAlpha((int)(80+120*(1-f.size/5))); c.drawCircle(f.x*w, f.y*h, f.size, p);} postInvalidateDelayed(16); }
    static class Flake {float x,y,size,speed,phase; Flake(float x,float y,float size,float speed,float phase){this.x=x;this.y=y;this.size=size;this.speed=speed;this.phase=phase;}}
}
