package com.example.akharinnamehshiraz;

import android.app.*;import android.os.*;import android.content.*;import android.media.*;import android.graphics.Color;import android.view.*;import android.widget.*;

public class SplashActivity extends Activity {
    private MediaPlayer wind;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.TRANSPARENT); getWindow().setNavigationBarColor(Color.TRANSPARENT); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        FrameLayout root=new FrameLayout(this); root.setBackgroundResource(com.example.akharinnamehshiraz.R.drawable.bg_splash); root.addView(new SnowView(this),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL); box.setPadding(32,0,32,0);
        TextView small=t("رمان عاشقانه • معمایی • اجتماعی",16,0xFFE7D9C4); small.setLetterSpacing(.04f); box.addView(small,new LinearLayout.LayoutParams(-2,-2));
        TextView title=t("آخرین نامه از شیراز",34,Color.WHITE); title.setTypeface(android.graphics.Typeface.create("serif",1)); title.setGravity(Gravity.CENTER); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=18;box.addView(title,tp);
        TextView author=t("نویسنده: میلاد شجیراتی",15,0xFFE5C58E); author.setGravity(Gravity.CENTER); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=8;box.addView(author,ap);
        TextView line=t("گاهی یک نامه، تمام زندگی را تغییر می‌دهد…",15,0xFFDCC9AF); line.setGravity(Gravity.CENTER); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=12;box.addView(line,lp);
        ProgressBar pb=new ProgressBar(this); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(48,48);pp.topMargin=34;box.addView(pb,pp);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);bp.gravity=Gravity.CENTER; root.addView(box,bp); setContentView(root);
        try{wind=MediaPlayer.create(this, R.raw.wind_soft); if(wind!=null){wind.setLooping(true);wind.setVolume(.18f,.18f);wind.start();}}catch(Exception ignored){}
        new Handler().postDelayed(()->{ if(wind!=null){wind.stop();wind.release();} startActivity(new Intent(this,MainActivity.class)); finish();},2800);
    }
    private TextView t(String s,int sp,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);return v;}
    @Override protected void onDestroy(){if(wind!=null){try{wind.release();}catch(Exception ignored){}}super.onDestroy();}
}
