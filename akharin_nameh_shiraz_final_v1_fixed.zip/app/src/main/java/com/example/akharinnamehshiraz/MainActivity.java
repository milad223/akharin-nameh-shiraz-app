package com.example.akharinnamehshiraz;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.recyclerview.widget.*;import org.json.*;import java.io.*;import java.util.*;

public class MainActivity extends AppCompatActivity {
    ArrayList<Chapter> all=new ArrayList<>(); ChapterAdapter adapter;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);getWindow().setStatusBarColor(Color.rgb(32,27,24));
        load(); RecyclerView rv=findViewById(R.id.list);rv.setLayoutManager(new LinearLayoutManager(this));adapter=new ChapterAdapter(this,all);rv.setAdapter(adapter);
        EditText search=findViewById(R.id.search); search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){adapter.filter(s.toString());}public void afterTextChanged(android.text.Editable e){}});
        findViewById(R.id.continueBtn).setOnClickListener(v->{int n=getPreferences(0).getInt("last",1);open(n);});
        findViewById(R.id.about).setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class)));
    }
    void load(){try{InputStream in=getAssets().open("chapters.json");ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)o.write(buf,0,n);JSONArray a=new JSONArray(o.toString("UTF-8"));for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);all.add(new Chapter(x.getInt("n"),x.getString("title"),x.getString("text")));}}catch(Exception e){Toast.makeText(this,"خطا در خواندن کتاب",Toast.LENGTH_LONG).show();}}
    void open(int n){Intent i=new Intent(this,ReaderActivity.class);i.putExtra("chapter",n);startActivity(i);}
    static class Chapter{int n;String title,text;Chapter(int n,String t,String x){this.n=n;title=t;text=x;}}
    class ChapterAdapter extends RecyclerView.Adapter<ChapterAdapter.VH>{Context c;ArrayList<Chapter> source,shown;ChapterAdapter(Context c,ArrayList<Chapter>s){this.c=c;source=s;shown=new ArrayList<>(s);}void filter(String q){shown.clear();q=q.trim();if(q.isEmpty())shown.addAll(source);else for(Chapter x:source)if(x.title.contains(q)||x.text.contains(q))shown.add(x);notifyDataSetChanged();}
        public VH onCreateViewHolder(android.view.ViewGroup p,int v){return new VH(getLayoutInflater().inflate(R.layout.item_chapter,p,false));}public void onBindViewHolder(VH h,int pos){Chapter x=shown.get(pos);h.num.setText(String.format(Locale.US,"%02d",x.n));h.title.setText(x.title);h.sub.setText(x.n==getPreferences(0).getInt("last",1)?"آخرین مطالعه شما":"فصل "+x.n);h.itemView.setOnClickListener(v->open(x.n));}public int getItemCount(){return shown.size();}
        class VH extends RecyclerView.ViewHolder{TextView num,title,sub;VH(View v){super(v);num=v.findViewById(R.id.number);title=v.findViewById(R.id.title);sub=v.findViewById(R.id.sub);}}
    }
}
