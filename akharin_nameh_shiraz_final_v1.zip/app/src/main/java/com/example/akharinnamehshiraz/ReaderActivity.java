
package com.example.akharinnamehshiraz;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.media.*;import android.view.*;import android.widget.*;import org.json.*;import java.io.*;import java.util.*;

public class ReaderActivity extends Activity{
 int id; ArrayList<MainActivity.Chapter> chapters=new ArrayList<>(); TextView title,textView; SharedPreferences prefs; MediaPlayer rain; SeekBar vol; float font=19f; int cream=Color.rgb(244,232,208),ink=Color.rgb(247,242,232),muted=Color.rgb(185,177,165),gold=Color.rgb(217,180,106),night=Color.rgb(11,16,23);
 public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("prefs",0);id=getIntent().getIntExtra("id",1);load();font=prefs.getFloat("font",19f);build();startRain();}
 void load(){try{String s=UI.asset(this,"chapters.json");JSONArray a=new JSONArray(s);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);chapters.add(new MainActivity.Chapter(o.getInt("id"),o.getString("title"),o.getString("subtitle"),o.getString("text")));}}catch(Exception e){}}
 TextView tv(String s,float z,int c){return UI.tv(this,s,z,c);}
 void build(){
  LinearLayout root=UI.col(this);root.setBackgroundColor(night);
  LinearLayout top=UI.row(this);top.setPadding(UI.dp(this,8),UI.dp(this,8),UI.dp(this,8),UI.dp(this,8));top.setBackgroundColor(Color.rgb(8,13,19));
  Button back=UI.button(this,"‹");top.addView(back,new LinearLayout.LayoutParams(UI.dp(this,48),UI.dp(this,50)));back.setOnClickListener(v->finish());
  LinearLayout ti=UI.col(this);title=tv("فصل "+id+" از "+chapters.size()+"  ·  "+chapters.get(id-1).title,18,ink);title.setTypeface(null,1);ti.addView(title,new LinearLayout.LayoutParams(0,UI.dp(this,30),1));ti.addView(tv( "آخرین نامه از شیراز",11,muted),new LinearLayout.LayoutParams(0,UI.dp(this,22),1));top.addView(ti,new LinearLayout.LayoutParams(0,UI.dp(this,50),1));
  Button bm=UI.button(this,prefs.getBoolean("bm"+id,false)?"★":"☆");top.addView(bm,new LinearLayout.LayoutParams(UI.dp(this,52),UI.dp(this,50)));bm.setOnClickListener(v->{boolean n=!prefs.getBoolean("bm"+id,false);prefs.edit().putBoolean("bm"+id,n).apply();bm.setText(n?"★":"☆");});
  Button more=UI.button(this,"Aa");top.addView(more,new LinearLayout.LayoutParams(UI.dp(this,58),UI.dp(this,50)));more.setOnClickListener(v->showTextOptions());
  root.addView(top);
  LinearLayout bar=UI.row(this);bar.setPadding(UI.dp(this,12),UI.dp(this,6),UI.dp(this,12),UI.dp(this,6));bar.setBackgroundColor(Color.rgb(17,25,34));TextView sound=tv("☁  صدای باران و رعد",12,gold);bar.addView(sound,new LinearLayout.LayoutParams(0,UI.dp(this,40),1));vol=new SeekBar(this);vol.setMax(100);vol.setProgress(prefs.getInt("vol",55));vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){if(rain!=null)rain.setVolume(p/100f,p/100f);prefs.edit().putInt("vol",p).apply();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});bar.addView(vol,new LinearLayout.LayoutParams(UI.dp(this,120),UI.dp(this,40)));root.addView(bar);
  ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout body=UI.col(this);body.setPadding(UI.dp(this,20),UI.dp(this,22),UI.dp(this,20),UI.dp(this,24));
  TextView chap=tv(chapters.get(id-1).subtitle,12,gold);chap.setGravity(Gravity.RIGHT);body.addView(chap,new LinearLayout.LayoutParams(-1,UI.dp(this,32)));
  textView=tv(chapters.get(id-1).text,font,cream);textView.setGravity(Gravity.RIGHT|Gravity.TOP);textView.setLineSpacing(9,1.16f);textView.setPadding(0,UI.dp(this,8),0,UI.dp(this,16));body.addView(textView,new LinearLayout.LayoutParams(-1,-2));sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout nav=UI.row(this);nav.setPadding(UI.dp(this,12),UI.dp(this,8),UI.dp(this,12),UI.dp(this,8));nav.setBackgroundColor(Color.rgb(8,13,19));
  Button prev=UI.button(this,"→  فصل قبل");Button next=UI.button(this,"فصل بعد  ←");nav.addView(prev,new LinearLayout.LayoutParams(0,UI.dp(this,52),1));nav.addView(next,new LinearLayout.LayoutParams(0,UI.dp(this,52),1));prev.setEnabled(id>1);next.setEnabled(id<chapters.size());prev.setOnClickListener(v->go(id-1));next.setOnClickListener(v->go(id+1));root.addView(nav,new LinearLayout.LayoutParams(-1,UI.dp(this,70)));setContentView(root);
 }
 void go(int n){prefs.edit().putInt("last",n).apply();Intent i=new Intent(this,ReaderActivity.class);i.putExtra("id",n);startActivity(i);finish();}
 void showTextOptions(){final String[] opts={"کوچک","متوسط","بزرگ","خیلی بزرگ","فونت کلاسیک"};new AlertDialog.Builder(this).setTitle("تنظیمات مطالعه").setSingleChoiceItems(opts,font<18?0:font<20?1:font<23?2:font<25?3:4,(d,w)->{if(w<4){font=new float[]{16,19,22,25}[w];textView.setTypeface(android.graphics.Typeface.create("sans",android.graphics.Typeface.NORMAL));}else{textView.setTypeface(android.graphics.Typeface.create("serif",android.graphics.Typeface.NORMAL));font=19;}textView.setTextSize(font);prefs.edit().putFloat("font",font).apply();d.dismiss();}).show();}
 void startRain(){try{int res=getResources().getIdentifier("rain_thunder","raw",getPackageName());rain=MediaPlayer.create(this,res);if(rain!=null){rain.setLooping(true);float v=prefs.getInt("vol",55)/100f;rain.setVolume(v,v);rain.start();}}catch(Exception e){}}
 protected void onPause(){super.onPause();if(rain!=null&&isFinishing()){try{rain.stop();}catch(Exception e){}rain.release();rain=null;}}
}
