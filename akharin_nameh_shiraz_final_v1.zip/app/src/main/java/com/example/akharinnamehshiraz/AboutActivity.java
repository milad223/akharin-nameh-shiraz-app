
package com.example.akharinnamehshiraz;
import android.app.*;import android.os.*;import android.graphics.*;import android.view.*;import android.widget.*;import android.content.*;

public class AboutActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout root=UI.col(this);root.setBackgroundColor(Color.rgb(11,16,23));root.setPadding(UI.dp(this,20),UI.dp(this,28),UI.dp(this,20),UI.dp(this,20));
  TextView h=UI.tv(this,"درباره برنامه",28,Color.rgb(247,242,232));h.setTypeface(null,1);root.addView(h,new LinearLayout.LayoutParams(-1,UI.dp(this,56)));
  TextView a=UI.tv(this,"آخرین نامه از شیراز\n\nنویسنده: میلاد شجیراتی\n\nژانر: عاشقانه · معمایی · اجتماعی\n\n۳۰ فصل کامل با امکان جست‌وجو، ادامه مطالعه، نشانک، تنظیم اندازه فونت، فصل قبل/بعد و صدای محیطی هنگام مطالعه.\n\nهنگام ورود، فضای برفی و موسیقی آرام ایجاد می‌شود و در زمان مطالعه صدای باران و رعد قابل پخش است.\n\nنسخه کتاب: v1.0\nنسخه برنامه: 1.0.0\n\nاین برنامه برای مطالعه آفلاین رمان طراحی شده است.",17,Color.rgb(244,232,208));a.setGravity(Gravity.RIGHT|Gravity.TOP);a.setLineSpacing(8,1.15f);root.addView(a,new LinearLayout.LayoutParams(-1,0,1));
  Button back=UI.button(this,"بازگشت");back.setBackground(UI.bg(Color.rgb(217,180,106),UI.dp(this,18)));back.setTextColor(Color.rgb(11,16,23));back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(-1,UI.dp(this,54)));setContentView(root);}
}
