package com.example.akharinnamehshiraz;
import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import java.io.*;
public class UI {
 static final int BG=Color.rgb(8,13,19), SURFACE=Color.rgb(16,24,32), SURFACE2=Color.rgb(22,33,43), GOLD=Color.rgb(216,181,106), CREAM=Color.rgb(247,240,227), MUTED=Color.rgb(155,163,173), LINE=Color.rgb(48,61,72);
 static int dp(Context c,int v){return (int)(v*c.getResources().getDisplayMetrics().density+.5f);} 
 static Typeface naskh(Context c,boolean bold){try{return Typeface.createFromAsset(c.getAssets(),bold?"fonts/NotoNaskhArabic-Bold.ttf":"fonts/NotoNaskhArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT;}}
 static Typeface kufi(Context c,boolean black){try{return Typeface.createFromAsset(c.getAssets(),black?"fonts/NotoKufiArabic-Black.ttf":"fonts/NotoKufiArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT_BOLD;}}
 static TextView tv(Context c,String s,float size,int color,boolean bold){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setTypeface(naskh(c,bold));t.setIncludeFontPadding(true);t.setPadding(dp(c,2),dp(c,2),dp(c,2),dp(c,2));t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return t;}
 static TextView heading(Context c,String s,float size){TextView t=tv(c,s,size,CREAM,true);t.setTypeface(kufi(c,true));return t;}
 static GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
 static GradientDrawable strokeBg(int color,float r,int sc,int sw){GradientDrawable g=bg(color,r);g.setStroke(sw,sc);return g;}
 static GradientDrawable gradient(float r,int... colors){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(r);return g;}
 static void margin(View v,int l,int t,int r,int b){if(v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams();p.setMargins(l,t,r,b);v.setLayoutParams(p);}}
 static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
 static LinearLayout col(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
 static ImageButton icon(Context c,int res){ImageButton b=new ImageButton(c);b.setImageResource(res);b.setColorFilter(GOLD,PorterDuff.Mode.SRC_IN);b.setBackground(bg(Color.TRANSPARENT,dp(c,18)));b.setPadding(dp(c,11),dp(c,11),dp(c,11),dp(c,11));return b;}
 static String asset(Context c,String name){try{InputStream in=c.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();return new String(out.toByteArray(),"UTF-8");}catch(Exception e){return "";}}
}
