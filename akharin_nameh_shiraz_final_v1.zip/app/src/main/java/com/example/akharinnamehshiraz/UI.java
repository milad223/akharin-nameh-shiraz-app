package com.example.akharinnamehshiraz;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;

public class UI {
    static final int BG=Color.rgb(5,8,14);
    static final int SURFACE=Color.rgb(13,19,29);
    static final int SURFACE2=Color.rgb(19,28,41);
    static final int GOLD=Color.rgb(231,190,103);
    static final int GOLD2=Color.rgb(178,132,54);
    static final int CREAM=Color.rgb(250,246,235);
    static final int MUTED=Color.rgb(164,169,179);
    static final int LINE=Color.rgb(48,59,74);
    static final int BLUE=Color.rgb(58,86,125);
    static int dp(Context c,int v){return (int)(v*c.getResources().getDisplayMetrics().density+.5f);}
    static Typeface naskh(Context c, boolean bold){try{return Typeface.createFromAsset(c.getAssets(),bold?"fonts/NotoNaskhArabic-Bold.ttf":"fonts/NotoNaskhArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT;}}
    static Typeface kufi(Context c, boolean black){try{return Typeface.createFromAsset(c.getAssets(),black?"fonts/NotoKufiArabic-Black.ttf":"fonts/NotoKufiArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT_BOLD;}}
    static TextView tv(Context c,String s,float size,int color,boolean bold){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setTypeface(naskh(c,bold));t.setIncludeFontPadding(false);t.setPadding(dp(c,2),0,dp(c,2),0);t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return t;}
    static TextView heading(Context c,String s,float size){TextView t=tv(c,s,size,CREAM,true);t.setTypeface(kufi(c,true));t.setIncludeFontPadding(false);return t;}
    static TextView overline(Context c,String s){TextView t=tv(c,s,10,GOLD,true);t.setLetterSpacing(.05f);return t;}
    static GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    static GradientDrawable strokeBg(int color,float radius,int strokeColor,int stroke){GradientDrawable g=bg(color,radius);g.setStroke(stroke,strokeColor);return g;}
    static GradientDrawable gradient(float radius,int... colors){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(radius);return g;}
    static void margin(View v,int l,int t,int r,int b){if(v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams();p.setMargins(l,t,r,b);v.setLayoutParams(p);}}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    static LinearLayout rowLTR(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);return l;}
    static LinearLayout col(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    static Button button(Context c,String s){Button b=new Button(c);b.setText(s);b.setTextSize(14);b.setTextColor(CREAM);b.setTypeface(naskh(c,true));b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setPadding(dp(c,6),0,dp(c,6),0);b.setMinHeight(0);b.setMinWidth(0);b.setBackground(bg(SURFACE2,dp(c,17)));return b;}
    static TextView action(Context c,String s){TextView t=tv(c,s,19,GOLD,true);t.setGravity(Gravity.CENTER);t.setBackground(strokeBg(Color.rgb(14,22,33),dp(c,16),Color.rgb(67,78,94),1));return t;}
    static String asset(Context c,String name){try{InputStream in=c.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();return new String(out.toByteArray(),"UTF-8");}catch(Exception e){return "";}}
}
