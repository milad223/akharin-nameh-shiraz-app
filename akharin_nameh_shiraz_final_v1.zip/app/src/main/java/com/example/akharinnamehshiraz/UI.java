
package com.example.akharinnamehshiraz;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

public class UI {
    static int dp(Context c, int v){ return (int)(v*c.getResources().getDisplayMetrics().density+0.5f); }
    static TextView tv(Context c,String s,float size,int color){ TextView t=new TextView(c); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setFontFeatureSettings("kern"); t.setPadding(dp(c,4),dp(c,2),dp(c,4),dp(c,2)); return t; }
    static GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    static GradientDrawable strokeBg(int color,float radius,int strokeColor,int stroke){ GradientDrawable g=bg(color,radius); g.setStroke(stroke,strokeColor); return g; }
    static void margin(View v,int l,int t,int r,int b){ if(v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){ ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams(); p.setMargins(l,t,r,b); v.setLayoutParams(p); } }
    static String asset(Context c,String name){ try { java.io.InputStream in=c.getAssets().open(name); java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream(); byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) out.write(b,0,n); in.close(); return new String(out.toByteArray(), "UTF-8"); } catch(Exception e){ return ""; } }
    static Button button(Context c,String text){ Button b=new Button(c); b.setText(text); b.setTextSize(13); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setPadding(dp(c,10),0,dp(c,10),0); return b; }
    static LinearLayout row(Context c){ LinearLayout l=new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    static LinearLayout col(Context c){ LinearLayout l=new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }
}
