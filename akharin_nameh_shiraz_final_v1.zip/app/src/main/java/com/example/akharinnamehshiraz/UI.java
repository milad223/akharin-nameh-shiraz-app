package com.example.akharinnamehshiraz;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.io.*;

public class UI {
    static final int BG = Color.rgb(4,7,13);
    static final int BG2 = Color.rgb(8,13,22);
    static final int PANEL = Color.rgb(11,18,29);
    static final int PANEL2 = Color.rgb(16,26,40);
    static final int GOLD = Color.rgb(239,194,104);
    static final int GOLD_SOFT = Color.rgb(211,164,75);
    static final int CREAM = Color.rgb(250,245,233);
    static final int TEXT = Color.rgb(235,231,222);
    static final int MUTED = Color.rgb(157,164,174);
    static final int LINE = Color.rgb(46,59,76);
    static final int CYAN = Color.rgb(104,168,181);

    static int dp(Context c,int v){return (int)(v*c.getResources().getDisplayMetrics().density+.5f);}
    static Typeface naskh(Context c, boolean bold){try{return Typeface.createFromAsset(c.getAssets(),bold?"fonts/NotoNaskhArabic-Bold.ttf":"fonts/NotoNaskhArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT;}}
    static Typeface kufi(Context c, boolean black){try{return Typeface.createFromAsset(c.getAssets(),black?"fonts/NotoKufiArabic-Black.ttf":"fonts/NotoKufiArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT_BOLD;}}

    static TextView tv(Context c,String s,float size,int color,boolean bold){
        TextView t=new TextView(c); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(naskh(c,bold)); t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true); t.setLineSpacing(dp(c,2),1.02f); t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        t.setPadding(dp(c,3),dp(c,3),dp(c,3),dp(c,3)); return t;
    }
    static TextView heading(Context c,String s,float size){
        TextView t=tv(c,s,size,CREAM,true); t.setTypeface(kufi(c,true)); t.setLineSpacing(dp(c,3),1.0f); return t;
    }
    static TextView label(Context c,String s){TextView t=tv(c,s,10,GOLD,true);t.setLetterSpacing(.04f);return t;}
    static TextView center(Context c,String s,float size,int color,boolean bold){TextView t=tv(c,s,size,color,bold);t.setGravity(Gravity.CENTER);return t;}
    static GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    static GradientDrawable strokeBg(int color,float radius,int strokeColor,int stroke){GradientDrawable g=bg(color,radius);g.setStroke(stroke,strokeColor);return g;}
    static GradientDrawable gradient(float radius,int... colors){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(radius);return g;}
    static void margin(View v,int l,int t,int r,int b){if(v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams();p.setMargins(l,t,r,b);v.setLayoutParams(p);}}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    static LinearLayout rowLTR(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);return l;}
    static LinearLayout col(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    static LinearLayout glass(Context c){LinearLayout l=col(c);l.setBackground(gradient(dp(c,24),Color.rgb(17,28,43),Color.rgb(9,16,27)));l.setPadding(dp(c,14),dp(c,12),dp(c,14),dp(c,12));return l;}
    static TextView pill(Context c,String s){TextView t=center(c,s,11,GOLD,true);t.setBackground(strokeBg(Color.rgb(13,22,34),dp(c,14),Color.rgb(83,72,52),1));t.setPadding(dp(c,10),dp(c,2),dp(c,10),dp(c,2));return t;}
    static TextView action(Context c,String s){TextView t=center(c,s,18,GOLD,true);t.setBackground(strokeBg(Color.rgb(9,16,26),dp(c,16),Color.rgb(72,83,99),1));return t;}
    static TextView button(Context c,String s){TextView t=center(c,s,13,CREAM,true);t.setBackground(gradient(dp(c,17),Color.rgb(24,37,53),Color.rgb(12,21,32)));t.setPadding(dp(c,8),0,dp(c,8),0);return t;}
    static String asset(Context c,String name){try{InputStream in=c.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();return new String(out.toByteArray(),"UTF-8");}catch(Exception e){return "";}}
}
