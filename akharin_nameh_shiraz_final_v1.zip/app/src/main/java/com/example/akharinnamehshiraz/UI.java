package com.example.akharinnamehshiraz;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;

public class UI {
    static final int BG=Color.rgb(5,9,16), BG2=Color.rgb(9,14,24), SURFACE=Color.rgb(14,22,33), SURFACE2=Color.rgb(20,30,43);
    static final int GOLD=Color.rgb(225,185,101), GOLD2=Color.rgb(247,213,139), CREAM=Color.rgb(250,245,234), MUTED=Color.rgb(166,168,173), LINE=Color.rgb(52,64,79);
    static final int PLUM=Color.rgb(48,28,51), BLUE=Color.rgb(16,35,52);
    static int dp(Context c,int v){return (int)(v*c.getResources().getDisplayMetrics().density+.5f);}
    static Typeface naskh(Context c, boolean bold){try{return Typeface.createFromAsset(c.getAssets(),bold?"fonts/NotoNaskhArabic-Bold.ttf":"fonts/NotoNaskhArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT;}}
    static Typeface kufi(Context c, boolean black){try{return Typeface.createFromAsset(c.getAssets(),black?"fonts/NotoKufiArabic-Black.ttf":"fonts/NotoKufiArabic-Regular.ttf");}catch(Exception e){return Typeface.DEFAULT_BOLD;}}
    static TextView tv(Context c,String s,float size,int color,boolean bold){
        TextView t=new TextView(c); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setTypeface(naskh(c,bold)); t.setIncludeFontPadding(true); t.setLineSpacing(0,1.0f); t.setPadding(dp(c,3),dp(c,5),dp(c,3),dp(c,5));
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return t;
    }
    static TextView heading(Context c,String s,float size){TextView t=tv(c,s,size,CREAM,true);t.setTypeface(kufi(c,true));t.setLineSpacing(0,1.02f);return t;}
    static GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    static GradientDrawable strokeBg(int color,float radius,int strokeColor,int stroke){GradientDrawable g=bg(color,radius);g.setStroke(stroke,strokeColor);return g;}
    static GradientDrawable gradient(float radius,int... colors){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(radius);return g;}
    static void margin(View v,int l,int t,int r,int b){if(v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams();p.setMargins(l,t,r,b);v.setLayoutParams(p);}}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    static LinearLayout col(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    static Button button(Context c,String s){Button b=new Button(c);b.setText(s);b.setTextSize(13);b.setTextColor(CREAM);b.setTypeface(naskh(c,true));b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setPadding(dp(c,8),dp(c,2),dp(c,8),dp(c,2));b.setMinHeight(0);b.setMinWidth(0);b.setBackground(bg(SURFACE2,dp(c,16)));return b;}
    static ImageView image(Context c,int res){ImageView i=new ImageView(c);i.setImageResource(res);i.setScaleType(ImageView.ScaleType.CENTER_CROP);return i;}
    static TextView label(Context c,String s){TextView t=tv(c,s,11,MUTED,false);t.setGravity(Gravity.CENTER);return t;}
    static String asset(Context c,String name){try{InputStream in=c.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();return new String(out.toByteArray(),"UTF-8");}catch(Exception e){return "";}}
}
