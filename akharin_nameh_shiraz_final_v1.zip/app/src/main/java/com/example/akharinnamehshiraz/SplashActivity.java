package com.example.akharinnamehshiraz;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.view.*;import android.widget.*;import android.media.*;import java.util.*;

public class SplashActivity extends Activity{
    MediaPlayer music;
    public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(3,7,13)); getWindow().setNavigationBarColor(Color.rgb(3,7,13));
        FrameLayout frame=new FrameLayout(this); frame.setBackgroundColor(UI.BG);
        ImageView bg=UI.image(this,getResources().getIdentifier("splash_hero","drawable",getPackageName())); frame.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        SnowView snow=new SnowView(this); frame.addView(snow,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout overlay=UI.col(this); overlay.setGravity(Gravity.CENTER_HORIZONTAL); overlay.setPadding(UI.dp(this,28),0,UI.dp(this,28),0);
        ImageView logo=UI.image(this,getResources().getIdentifier("ic_launcher","drawable",getPackageName())); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        overlay.addView(logo,new LinearLayout.LayoutParams(UI.dp(this,110),UI.dp(this,110)));
        TextView title=UI.heading(this,"آخرین نامه از شیراز",29); title.setGravity(Gravity.CENTER); title.setShadowLayer(18,0,4,Color.argb(120,0,0,0));
        overlay.addView(title,new LinearLayout.LayoutParams(-1,UI.dp(this,62)));
        TextView sub=UI.tv(this,"رمان عاشقانه • معمایی • اجتماعی",14,UI.GOLD2,true);sub.setGravity(Gravity.CENTER);
        overlay.addView(sub,new LinearLayout.LayoutParams(-1,UI.dp(this,40)));
        LinearLayout author=UI.row(this); author.setGravity(Gravity.CENTER); author.setPadding(UI.dp(this,16),UI.dp(this,8),UI.dp(this,16),UI.dp(this,8)); author.setBackground(UI.strokeBg(Color.argb(180,12,20,30),UI.dp(this,24),Color.rgb(120,101,64),1));
        TextView mon=UI.tv(this,"م",19,UI.GOLD,true);mon.setGravity(Gravity.CENTER);mon.setBackground(UI.bg(Color.rgb(46,37,49),UI.dp(this,20)));author.addView(mon,new LinearLayout.LayoutParams(UI.dp(this,40),UI.dp(this,40)));
        TextView at=UI.tv(this,"میلاد شجیراتی\nنویسنده و صاحب اثر",12,UI.CREAM,true);at.setGravity(Gravity.CENTER);author.addView(at,new LinearLayout.LayoutParams(UI.dp(this,190),UI.dp(this,54)));overlay.addView(author,new LinearLayout.LayoutParams(-2,UI.dp(this,58)));
        LinearLayout meta=UI.row(this);meta.setGravity(Gravity.CENTER);String[] ms={"۳۰ فصل کامل","مطالعه آفلاین","نسخه نهایی ۴.۰"};for(String s:ms){TextView m=UI.tv(this,s,10,UI.MUTED,false);m.setGravity(Gravity.CENTER);meta.addView(m,new LinearLayout.LayoutParams(0,UI.dp(this,34),1));}overlay.addView(meta,new LinearLayout.LayoutParams(UI.dp(this,330),UI.dp(this,40)));
        TextView quote=UI.tv(this,"«بعضی نامه‌ها برای خوانده‌شدن نیستند؛ برای پیدا کردن حقیقت‌اند.»",12,Color.rgb(210,201,181),false);quote.setGravity(Gravity.CENTER);overlay.addView(quote,new LinearLayout.LayoutParams(-1,UI.dp(this,54)));
        ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setIndeterminate(true);overlay.addView(pb,new LinearLayout.LayoutParams(UI.dp(this,180),UI.dp(this,5)));
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,UI.dp(this,470),Gravity.CENTER);op.topMargin=UI.dp(this,260);frame.addView(overlay,op);
        TextView footer=UI.tv(this,"فضای آرام برای خواندن و تمرکز",11,UI.MUTED,false);footer.setGravity(Gravity.CENTER);FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(-1,UI.dp(this,48),Gravity.BOTTOM);fp.bottomMargin=UI.dp(this,28);frame.addView(footer,fp);
        setContentView(frame);
        try{music=MediaPlayer.create(this,getResources().getIdentifier("entry","raw",getPackageName()));if(music!=null){music.setLooping(true);music.setVolume(.48f,.48f);music.start();}}catch(Exception ignored){}
        new Handler().postDelayed(()->{release();startActivity(new Intent(this,MainActivity.class));finish();},5200);
    }
    void release(){try{if(music!=null){music.stop();music.release();music=null;}}catch(Exception ignored){}}
    protected void onDestroy(){release();super.onDestroy();}
    static class SnowView extends View{Paint p=new Paint(3);Random r=new Random(19);ArrayList<F> fs=new ArrayList<>();SnowView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);for(int i=0;i<95;i++)fs.add(new F(r));}protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();for(F f:fs){p.setColor(Color.argb(f.a,242,247,250));c.drawCircle(f.x,f.y,f.s,p);f.y+=f.v;f.x+=Math.sin(f.t)*.25f;f.t+=.014f;if(f.y>h+8){f.y=-8;f.x=r.nextInt(Math.max(1,w));}}postInvalidateDelayed(22);}static class F{float x,y,s,v,t;int a;F(Random r){x=r.nextFloat()*1200;y=r.nextFloat()*2400;s=.8f+r.nextFloat()*2.7f;v=.35f+r.nextFloat()*1.8f;t=r.nextFloat()*6.28f;a=45+r.nextInt(125);}}}
}
