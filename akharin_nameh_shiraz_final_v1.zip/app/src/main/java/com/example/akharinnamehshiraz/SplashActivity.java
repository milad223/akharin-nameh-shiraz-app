
package com.example.akharinnamehshiraz;
import android.app.*;import android.os.*;import android.content.*;import android.media.*;import android.view.*;import android.graphics.*;import java.util.*;

public class SplashActivity extends Activity{
 MediaPlayer music, wind;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(5,10,15)); SnowView v=new SnowView(this);setContentView(v);
  try{
   music=MediaPlayer.create(this,getResources().getIdentifier("entry","raw",getPackageName()));
   wind=MediaPlayer.create(this,getResources().getIdentifier("wind_snow","raw",getPackageName()));
   if(music!=null){music.setLooping(true);music.setVolume(.55f,.55f);music.start();}
   if(wind!=null){wind.setLooping(true);wind.setVolume(.38f,.38f);wind.start();}
  }catch(Exception e){}
  new Handler().postDelayed(()->{if(music!=null){music.stop();music.release();music=null;}if(wind!=null){wind.stop();wind.release();wind=null;}startActivity(new Intent(this,MainActivity.class));finish();},3600);
 }
 protected void onDestroy(){if(music!=null){try{music.stop();}catch(Exception e){}music.release();}if(wind!=null){try{wind.stop();}catch(Exception e){}wind.release();}super.onDestroy();}
 static class SnowView extends View{
  Paint p=new Paint(3);Random r=new Random();ArrayList<Flake> flakes=new ArrayList<>();long start;
  SnowView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);for(int i=0;i<110;i++)flakes.add(new Flake(r));start=System.currentTimeMillis();}
  protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();LinearGradient g=new LinearGradient(0,0,w,h,Color.rgb(8,18,29),Color.rgb(29,38,48),Shader.TileMode.CLAMP);p.setShader(g);c.drawRect(0,0,w,h,p);p.setShader(null);
   p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(Math.min(w*.085f,58));p.setColor(Color.rgb(244,232,208));c.drawText("آخرین نامه از شیراز",w/2f,h*.43f,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(17);p.setColor(Color.rgb(217,180,106));c.drawText("نویسنده: میلاد شجیراتی",w/2f,h*.49f,p);
   p.setTextSize(13);p.setColor(Color.rgb(185,177,165));c.drawText("در میان برف، بعضی خاطره‌ها دوباره زنده می‌شوند…",w/2f,h*.55f,p);
   for(Flake f:flakes){p.setColor(Color.argb(f.a,235,244,250));c.drawCircle(f.x,f.y,f.s,p);f.y+=f.v;if(f.y>h+8)f.y=-8;if(f.x>w+5)f.x=-5;if(f.x<-5)f.x=w+5;f.x+=Math.sin((System.currentTimeMillis()-start)/700.0+f.phase)*.35;}
   postInvalidateDelayed(16);
  }
  static class Flake{float x,y,s,v,phase;int a;Flake(Random r){x=r.nextFloat()*900;y=r.nextFloat()*1800;s=1+r.nextFloat()*3;v=.7f+r.nextFloat()*2.2f;phase=r.nextFloat()*6;a=90+r.nextInt(130);}}
 }
}
