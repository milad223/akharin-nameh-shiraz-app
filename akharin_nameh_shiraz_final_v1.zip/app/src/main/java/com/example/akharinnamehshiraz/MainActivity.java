
package com.example.akharinnamehshiraz;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    ArrayList<Chapter> chapters=new ArrayList<>();
    LinearLayout list;
    EditText search;
    SharedPreferences prefs;
    int gold=Color.rgb(217,180,106), cream=Color.rgb(244,232,208), ink=Color.rgb(247,242,232), muted=Color.rgb(185,177,165), night=Color.rgb(11,16,23), panel=Color.rgb(23,33,44);

    public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("prefs",0); load(); build();}
    void load(){try{String s=UI.asset(this,"chapters.json");JSONArray a=new JSONArray(s);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);chapters.add(new Chapter(o.getInt("id"),o.getString("title"),o.getString("subtitle"),o.getString("text")));}}catch(Exception e){}}
    TextView text(String s,float z,int c){return UI.tv(this,s,z,c);}
    public void build(){
        LinearLayout root=UI.col(this); root.setBackgroundColor(night);
        ScrollView sv=new ScrollView(this); LinearLayout content=UI.col(this); content.setPadding(UI.dp(this,18),UI.dp(this,18),UI.dp(this,18),UI.dp(this,90));
        LinearLayout hero=UI.col(this); GradientDrawable hg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(33,47,61),Color.rgb(67,43,50),Color.rgb(20,26,34)}); hg.setCornerRadius(UI.dp(this,28)); hero.setBackground(hg); hero.setPadding(UI.dp(this,20),UI.dp(this,20),UI.dp(this,20),UI.dp(this,22));
        TextView tiny=text("رمان ایرانی  •  عاشقانه · معمایی · اجتماعی",12,gold); hero.addView(tiny,new LinearLayout.LayoutParams(-1,UI.dp(this,28)));
        TextView title=text("آخرین نامه از شیراز",30,ink); title.setTypeface(null,1); hero.addView(title,new LinearLayout.LayoutParams(-1,UI.dp(this,52)));
        TextView sub=text("گاهی یک نامه، تمام زندگی را تغییر می‌دهد…",15,cream); hero.addView(sub,new LinearLayout.LayoutParams(-1,UI.dp(this,38)));
        LinearLayout meta=UI.row(this); meta.setPadding(0,UI.dp(this,10),0,0); TextView au=text("نویسنده: میلاد شجیراتی",13,muted); meta.addView(au,new LinearLayout.LayoutParams(0,UI.dp(this,36),1)); TextView ver=text("نسخه کتاب: v1.0",12,gold); meta.addView(ver,new LinearLayout.LayoutParams(UI.dp(this,130),UI.dp(this,36))); hero.addView(meta);
        content.addView(hero,new LinearLayout.LayoutParams(-1,UI.dp(this,180)));
        int last=prefs.getInt("last",1);
        LinearLayout cont=UI.col(this); cont.setBackground(UI.strokeBg(Color.rgb(27,39,51),UI.dp(this,22),Color.rgb(50,64,78),1)); cont.setPadding(UI.dp(this,16),UI.dp(this,10),UI.dp(this,16),UI.dp(this,12)); UI.margin(cont,0,UI.dp(this,16),0,0);
        TextView ct=text("ادامه مطالعه",12,gold); cont.addView(ct,new LinearLayout.LayoutParams(-1,UI.dp(this,28)));
        Chapter lc=chapters.size()>=last?chapters.get(last-1):chapters.get(0); TextView lt=text(lc.id+"  ·  "+lc.title,20,ink); lt.setTypeface(null,1); cont.addView(lt,new LinearLayout.LayoutParams(-1,UI.dp(this,42)));
        TextView go=text("باز کردن فصل  ←",13,cream); cont.addView(go,new LinearLayout.LayoutParams(-1,UI.dp(this,34))); cont.setOnClickListener(v->open(last));
        content.addView(cont);
        search=new EditText(this); search.setSingleLine(true); search.setHint("جست‌وجو در فصل‌ها…"); search.setHintTextColor(Color.rgb(120,132,145)); search.setTextColor(ink); search.setTextSize(15); search.setPadding(UI.dp(this,16),0,UI.dp(this,16),0); search.setBackground(UI.bg(Color.rgb(20,29,39),UI.dp(this,18))); UI.margin(search,0,UI.dp(this,18),0,0); content.addView(search,new LinearLayout.LayoutParams(-1,UI.dp(this,52))); search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){render(s.toString());}public void afterTextChanged(android.text.Editable e){}});

        TextView head=text("فصل‌های رمان",22,ink); head.setTypeface(null,1); UI.margin(head,0,UI.dp(this,18),0,UI.dp(this,6)); content.addView(head,new LinearLayout.LayoutParams(-1,UI.dp(this,42)));
        list=UI.col(this); content.addView(list,new LinearLayout.LayoutParams(-1,-2)); render("");
        TextView about=text("درباره کتاب و نویسنده  ·  تنظیمات مطالعه",13,gold); about.setGravity(Gravity.CENTER); about.setPadding(0,UI.dp(this,20),0,UI.dp(this,20)); about.setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class))); content.addView(about,new LinearLayout.LayoutParams(-1,UI.dp(this,60)));
        sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=UI.row(this); nav.setPadding(UI.dp(this,10),UI.dp(this,8),UI.dp(this,10),UI.dp(this,8)); nav.setBackgroundColor(Color.rgb(8,13,19));
        Button home=UI.button(this,"⌂  خانه"); home.setTextColor(gold); nav.addView(home,new LinearLayout.LayoutParams(0,UI.dp(this,52),1));
        Button marks=UI.button(this,"♡  نشانک‌ها"); nav.addView(marks,new LinearLayout.LayoutParams(0,UI.dp(this,52),1)); marks.setOnClickListener(v->showBookmarks());
        Button info=UI.button(this,"ⓘ  درباره"); nav.addView(info,new LinearLayout.LayoutParams(0,UI.dp(this,52),1)); info.setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class)));
        root.addView(nav,new LinearLayout.LayoutParams(-1,UI.dp(this,70))); setContentView(root);
    }
    void render(String q){ if(list==null)return; list.removeAllViews(); for(Chapter c:chapters){ if(q.length()>0 && !(c.title.contains(q)||c.subtitle.contains(q)||c.text.contains(q)))continue; LinearLayout card=UI.row(this); card.setBackground(UI.strokeBg(panel,UI.dp(this,20),Color.rgb(47,61,75),1)); card.setPadding(UI.dp(this,12),UI.dp(this,8),UI.dp(this,12),UI.dp(this,8)); UI.margin(card,0,0,0,UI.dp(this,10));
        TextView n=text(String.format("%02d",c.id),22,gold); n.setGravity(Gravity.CENTER); card.addView(n,new LinearLayout.LayoutParams(UI.dp(this,52),UI.dp(this,68)));
        LinearLayout info=UI.col(this); TextView t=text(c.title,18,ink); t.setTypeface(null,1); info.addView(t,new LinearLayout.LayoutParams(-1,UI.dp(this,38))); info.addView(text(c.subtitle,12,muted),new LinearLayout.LayoutParams(-1,UI.dp(this,26))); card.addView(info,new LinearLayout.LayoutParams(0,UI.dp(this,68),1));
        TextView arrow=text("‹",28,gold); arrow.setGravity(Gravity.CENTER); card.addView(arrow,new LinearLayout.LayoutParams(UI.dp(this,28),UI.dp(this,68))); card.setOnClickListener(v->open(c.id)); list.addView(card);
    }}
    void open(int id){prefs.edit().putInt("last",id).apply();Intent i=new Intent(this,ReaderActivity.class);i.putExtra("id",id);startActivity(i);}
    void showBookmarks(){ArrayList<Integer> ids=new ArrayList<>();for(Chapter c:chapters)if(prefs.getBoolean("bm"+c.id,false))ids.add(c.id); if(ids.isEmpty()){new AlertDialog.Builder(this).setTitle("نشانک‌ها").setMessage("هنوز فصلی نشانک نشده است.").setPositiveButton("باشه",null).show();return;} StringBuilder s=new StringBuilder();for(int id:ids)s.append("فصل ").append(id).append(" — ").append(chapters.get(id-1).title).append("\n");new AlertDialog.Builder(this).setTitle("فصل‌های ذخیره‌شده").setMessage(s.toString()).setPositiveButton("باشه",null).show();}
    static class Chapter{int id;String title,subtitle,text;Chapter(int i,String t,String s,String x){id=i;title=t;subtitle=s;text=x;}}
}
