package com.example.akharinnamehshiraz;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import android.text.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    ArrayList<Chapter> chapters=new ArrayList<>();
    LinearLayout list;
    EditText search;
    SharedPreferences prefs;
    final int gold=Color.rgb(217,180,106), cream=Color.rgb(244,232,208), ink=Color.rgb(247,242,232), muted=Color.rgb(166,163,158), night=Color.rgb(7,11,16), panel=Color.rgb(18,27,37), panel2=Color.rgb(24,35,47), rose=Color.rgb(174,94,111);

    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(night); prefs=getSharedPreferences("prefs",0); load(); build();}
    void load(){try{String s=UI.asset(this,"chapters.json");JSONArray a=new JSONArray(s);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);chapters.add(new Chapter(o.getInt("id"),o.getString("title"),o.getString("subtitle"),o.getString("text")));}}catch(Exception e){}}
    TextView text(String s,float z,int c){return UI.tv(this,s,z,c);}
    TextView chip(String s){TextView t=text(s,11,cream);t.setGravity(Gravity.CENTER);t.setBackground(UI.strokeBg(Color.rgb(27,39,51),UI.dp(this,15),Color.rgb(62,72,83),1));return t;}

    public void build(){
        LinearLayout root=UI.col(this); root.setBackgroundColor(night);
        ScrollView sv=new ScrollView(this); LinearLayout content=UI.col(this); content.setPadding(UI.dp(this,16),UI.dp(this,14),UI.dp(this,16),UI.dp(this,30));

        LinearLayout top=UI.row(this); top.setGravity(Gravity.CENTER_VERTICAL); 
        TextView brand=text("آخرین نامه از شیراز",17,ink); brand.setTypeface(null,Typeface.BOLD); top.addView(brand,new LinearLayout.LayoutParams(0,UI.dp(this,48),1));
        Button about=UI.button(this,"ⓘ"); about.setTextColor(gold); about.setTextSize(21); about.setBackgroundColor(Color.TRANSPARENT); about.setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class))); top.addView(about,new LinearLayout.LayoutParams(UI.dp(this,48),UI.dp(this,48)));
        content.addView(top);

        LinearLayout hero=UI.row(this); GradientDrawable hg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(31,47,61),Color.rgb(53,34,44),Color.rgb(14,21,29)}); hg.setCornerRadius(UI.dp(this,30)); hero.setBackground(hg); hero.setPadding(UI.dp(this,16),UI.dp(this,16),UI.dp(this,16),UI.dp(this,16));
        LinearLayout cover=UI.col(this); cover.setGravity(Gravity.CENTER); GradientDrawable cg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(221,185,113),Color.rgb(122,66,76)}); cg.setCornerRadius(UI.dp(this,20)); cover.setBackground(cg); cover.setPadding(UI.dp(this,8),UI.dp(this,8),UI.dp(this,8),UI.dp(this,8));
        TextView coverIcon=text("✦",38,Color.rgb(25,27,29));coverIcon.setGravity(Gravity.CENTER);cover.addView(coverIcon,new LinearLayout.LayoutParams(-1,UI.dp(this,45)));
        TextView coverTitle=text("آخرین\nنامه\nاز شیراز",17,Color.rgb(28,29,30));coverTitle.setGravity(Gravity.CENTER);coverTitle.setTypeface(null,Typeface.BOLD);cover.addView(coverTitle,new LinearLayout.LayoutParams(-1,UI.dp(this,82)));
        TextView coverAuthor=text("میلاد شجیراتی",9,Color.rgb(47,39,35));coverAuthor.setGravity(Gravity.CENTER);cover.addView(coverAuthor,new LinearLayout.LayoutParams(-1,UI.dp(this,24)));
        hero.addView(cover,new LinearLayout.LayoutParams(UI.dp(this,112),UI.dp(this,154)));
        LinearLayout ht=UI.col(this); ht.setPadding(UI.dp(this,18),0,UI.dp(this,4),0);
        TextView genre=text("رمان ایرانی  •  عاشقانه · معمایی · اجتماعی",11,gold);ht.addView(genre,new LinearLayout.LayoutParams(-1,UI.dp(this,30)));
        TextView title=text("آخرین نامه\nاز شیراز",28,ink);title.setTypeface(null,Typeface.BOLD);ht.addView(title,new LinearLayout.LayoutParams(-1,UI.dp(this,76)));
        TextView quote=text("گاهی یک نامه، تمام زندگی را تغییر می‌دهد…",13,cream);quote.setLineSpacing(3,1.05f);ht.addView(quote,new LinearLayout.LayoutParams(-1,UI.dp(this,46)));
        TextView author=text("نویسنده: میلاد شجیراتی",12,muted);ht.addView(author,new LinearLayout.LayoutParams(-1,UI.dp(this,30)));
        hero.addView(ht,new LinearLayout.LayoutParams(0,UI.dp(this,154),1)); content.addView(hero,new LinearLayout.LayoutParams(-1,UI.dp(this,186)));

        LinearLayout chips=UI.row(this); chips.setPadding(0,UI.dp(this,12),0,UI.dp(this,4));
        TextView c1=chip("۳۰ فصل کامل"); TextView c2=chip("آفلاین"); TextView c3=chip("صدای محیطی"); chips.addView(c1,new LinearLayout.LayoutParams(0,UI.dp(this,34),1)); chips.addView(c2,new LinearLayout.LayoutParams(0,UI.dp(this,34),1)); chips.addView(c3,new LinearLayout.LayoutParams(0,UI.dp(this,34),1)); content.addView(chips);

        int last=prefs.getInt("last",1); if(chapters.size()>0){
            LinearLayout cont=UI.col(this);cont.setBackground(UI.strokeBg(Color.rgb(20,30,41),UI.dp(this,22),Color.rgb(55,69,83),1));cont.setPadding(UI.dp(this,16),UI.dp(this,11),UI.dp(this,16),UI.dp(this,12));UI.margin(cont,0,UI.dp(this,12),0,0);
            TextView label=text("ادامه مطالعه",11,gold);cont.addView(label,new LinearLayout.LayoutParams(-1,UI.dp(this,24)));
            Chapter lc=chapters.get(Math.max(0,Math.min(last,chapters.size())-1));TextView lt=text("فصل "+lc.id+"  ·  "+lc.title,18,ink);lt.setTypeface(null,Typeface.BOLD);cont.addView(lt,new LinearLayout.LayoutParams(-1,UI.dp(this,38)));
            TextView desc=text("ادامه از همان‌جایی که متوقف شدی  ←",12,muted);cont.addView(desc,new LinearLayout.LayoutParams(-1,UI.dp(this,28)));cont.setOnClickListener(v->open(lc.id));content.addView(cont);
        }

        search=new EditText(this);search.setSingleLine(true);search.setHint("جست‌وجوی عنوان، فصل یا متن…");search.setHintTextColor(Color.rgb(116,127,139));search.setTextColor(ink);search.setTextSize(14);search.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);search.setPadding(UI.dp(this,18),0,UI.dp(this,18),0);search.setBackground(UI.strokeBg(Color.rgb(16,24,33),UI.dp(this,18),Color.rgb(48,62,77),1));UI.margin(search,0,UI.dp(this,14),0,0);content.addView(search,new LinearLayout.LayoutParams(-1,UI.dp(this,54)));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){render(s.toString());}public void afterTextChanged(Editable e){}});

        LinearLayout section=UI.row(this);TextView head=text("فصل‌های رمان",22,ink);head.setTypeface(null,Typeface.BOLD);section.addView(head,new LinearLayout.LayoutParams(0,UI.dp(this,52),1));TextView count=text("۳۰ فصل",12,gold);count.setGravity(Gravity.CENTER);section.addView(count,new LinearLayout.LayoutParams(UI.dp(this,70),UI.dp(this,52)));content.addView(section);
        list=UI.col(this);content.addView(list,new LinearLayout.LayoutParams(-1,-2));render("");
        TextView aboutText=text("درباره کتاب  ·  نویسنده  ·  امکانات مطالعه",12,gold);aboutText.setGravity(Gravity.CENTER);aboutText.setPadding(0,UI.dp(this,18),0,UI.dp(this,18));aboutText.setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class)));content.addView(aboutText,new LinearLayout.LayoutParams(-1,UI.dp(this,58)));
        sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=UI.row(this);nav.setPadding(UI.dp(this,10),UI.dp(this,7),UI.dp(this,10),UI.dp(this,7));nav.setBackgroundColor(Color.rgb(5,9,14));
        Button home=UI.button(this,"⌂\nخانه");home.setTextColor(gold);home.setTextSize(12);nav.addView(home,new LinearLayout.LayoutParams(0,UI.dp(this,58),1));
        Button marks=UI.button(this,"☆\nنشانک‌ها");marks.setTextSize(12);nav.addView(marks,new LinearLayout.LayoutParams(0,UI.dp(this,58),1));marks.setOnClickListener(v->showBookmarks());
        Button info=UI.button(this,"☰\nدرباره");info.setTextSize(12);nav.addView(info,new LinearLayout.LayoutParams(0,UI.dp(this,58),1));info.setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class)));
        root.addView(nav,new LinearLayout.LayoutParams(-1,UI.dp(this,70)));setContentView(root);
    }

    void render(String q){if(list==null)return;list.removeAllViews();for(Chapter c:chapters){if(q.length()>0&&!(c.title.contains(q)||c.subtitle.contains(q)||c.text.contains(q)))continue;LinearLayout card=UI.row(this);card.setBackground(UI.strokeBg(panel,UI.dp(this,21),Color.rgb(42,57,72),1));card.setPadding(UI.dp(this,10),UI.dp(this,7),UI.dp(this,12),UI.dp(this,7));UI.margin(card,0,0,0,UI.dp(this,9));
        TextView n=text(String.format("%02d",c.id),18,gold);n.setGravity(Gravity.CENTER);n.setTypeface(null,Typeface.BOLD);n.setBackground(UI.bg(Color.rgb(33,42,52),UI.dp(this,16)));card.addView(n,new LinearLayout.LayoutParams(UI.dp(this,52),UI.dp(this,64)));
        LinearLayout info=UI.col(this);info.setPadding(UI.dp(this,12),0,UI.dp(this,6),0);TextView t=text(c.title,17,ink);t.setTypeface(null,Typeface.BOLD);info.addView(t,new LinearLayout.LayoutParams(-1,UI.dp(this,34)));info.addView(text(c.subtitle,11,muted),new LinearLayout.LayoutParams(-1,UI.dp(this,27)));card.addView(info,new LinearLayout.LayoutParams(0,UI.dp(this,64),1));
        TextView arrow=text("‹",28,gold);arrow.setGravity(Gravity.CENTER);card.addView(arrow,new LinearLayout.LayoutParams(UI.dp(this,26),UI.dp(this,64)));card.setOnClickListener(v->open(c.id));list.addView(card);
    }}
    void open(int id){prefs.edit().putInt("last",id).apply();Intent i=new Intent(this,ReaderActivity.class);i.putExtra("id",id);startActivity(i);}
    void showBookmarks(){ArrayList<Integer> ids=new ArrayList<>();for(Chapter c:chapters)if(prefs.getBoolean("bm"+c.id,false))ids.add(c.id);if(ids.isEmpty()){new AlertDialog.Builder(this).setTitle("نشانک‌ها").setMessage("هنوز فصلی نشانک نشده است.").setPositiveButton("باشه",null).show();return;}StringBuilder s=new StringBuilder();for(int id:ids)s.append("فصل ").append(id).append(" — ").append(chapters.get(id-1).title).append("\n");new AlertDialog.Builder(this).setTitle("فصل‌های ذخیره‌شده").setMessage(s.toString()).setPositiveButton("باشه",null).show();}
    static class Chapter{int id;String title,subtitle,text;Chapter(int i,String t,String s,String x){id=i;title=t;subtitle=s;text=x;}}
}
