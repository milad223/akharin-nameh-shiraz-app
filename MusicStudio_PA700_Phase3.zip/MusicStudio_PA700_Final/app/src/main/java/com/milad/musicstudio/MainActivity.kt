package com.milad.musicstudio

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.milad.musicstudio.korg.PcmExtractor
import java.io.File

class MainActivity : Activity() {
    private val audio = AudioEngine()
    private lateinit var status: TextView
    private lateinit var report: TextView
    private var current: File? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(text: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE); if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(7), dp(10), dp(7))
    }
    private fun button(text: String): Button = Button(this).apply { this.text = text; isAllCaps = false }

    override fun onCreate(saved: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 24)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(12,15,20)); setPadding(dp(10), dp(8), dp(10), dp(8)) }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(tv("MUSIC STUDIO", 20f, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(tv("PA700 ENGINE  •  v3.0", 12f))
        root.addView(header)

        status = tv("READY  |  No SET loaded", 12f)
        status.setTextColor(Color.rgb(120, 220, 160)); root.addView(status)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("SOUND", "STYLE", "PAD", "PERFORM", "SET").forEach { tabs.addView(button(it), LinearLayout.LayoutParams(0, dp(46), 1f)) }
        root.addView(tabs)

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        info.addView(tv("Sound: Solo Violin", 18f, true))
        info.addView(tv("Style: —    Tempo: 98 BPM    Transpose: 0", 13f))
        root.addView(info)

        val keys = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val midiNotes = intArrayOf(60,62,64,65,67,69,71,72)
        val labels = arrayOf("C4","D4","E4","F4","G4","A4","B4","C5")
        for (i in midiNotes.indices) {
            val b = button(labels[i]); b.textSize = 11f; b.setOnClickListener { audio.note(midiNotes[i]); status.text = "PLAYING  |  ${labels[i]}  |  Solo Violin (test engine)" }
            keys.addView(b, LinearLayout.LayoutParams(0, dp(92), 1f).apply { setMargins(dp(2),0,dp(2),0) })
        }
        root.addView(keys)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val load = button("📂 Load PCG / KMP / PCM")
        val scan = button("🔎 Scan")
        val stop = button("■ Stop Audio")
        actions.addView(load, LinearLayout.LayoutParams(0, dp(50), 2f)); actions.addView(scan, LinearLayout.LayoutParams(0, dp(50), 1f)); actions.addView(stop, LinearLayout.LayoutParams(0, dp(50), 1f))
        root.addView(actions)

        report = tv("PA700 compatibility workspace\n• KORF detection\n• KMP/PCG name extraction\n• PCM boundary inspection\n• Experimental WAV probing", 12f)
        val scroll = ScrollView(this).apply { addView(report) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        load.setOnClickListener { pickFile() }
        scan.setOnClickListener { current?.let { scanFile(it) } ?: run { status.text = "READY  |  Select a PA file first" } }
        stop.setOnClickListener { audio.release(); status.text = "READY  |  Audio stopped" }
        setContentView(root)
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(i, 70)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 70 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val f = File(cacheDir, "selected_pa_file")
        contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { output -> input.copyTo(output) } }
        current = f
        scanFile(f)
    }

    private fun scanFile(file: File) {
        status.text = "SCANNING  |  ${file.length()} bytes"
        val rows = try { PcmExtractor.scan(file) } catch (_: Exception) { emptyList() }
        val korf = try { PcmExtractor.hasKorf(file) } catch (_: Exception) { false }
        val kend = try { PcmExtractor.hasKend(file) } catch (_: Exception) { false }
        report.text = buildString {
            append("FILE: ${file.name}\nSIZE: ${file.length()} bytes\n")
            append("KORF: $korf    KEND: $kend\n")
            append("RECORDS: ${rows.size}\n\n")
            rows.take(30).forEach { r ->
                append("#${r.index}  header=${r.headerOffset}  payload=${r.payloadBytes} bytes\n")
                append("range=${r.dataOffset}..${r.dataEnd}  f20=${r.f20} f24=${r.f24} f60=${r.f60} f64=${r.f64}\n")
                append("candidate=${r.compressedCandidate}  probes=${r.probe}\n\n")
            }
            append("\nNOTE: This scanner identifies observed structures; it does not claim complete decoding of KORG's proprietary sample compression.")
        }
        status.text = "READY  |  Scan complete"
    }

    override fun onDestroy() { audio.release(); super.onDestroy() }
}
