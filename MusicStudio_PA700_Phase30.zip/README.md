# Music Studio PA700 — Phase 30

## Milestone: Multisample-to-Keyboard Integration

Phase 30 consolidates the earlier KORF/KMP/PCM work into a small runtime path:

**KMP zone → SampleData → key/velocity selection → pitch-shifted AudioTrack playback**

### Added
- `SampleZone` with key and velocity ranges plus root key.
- `Multisample.select()` chooses the closest matching root key for a played note.
- `SamplePlayer.playZone()` performs linear-interpolated pitch shifting from root key to requested MIDI key.
- Velocity is applied as a playback gain factor.
- `Phase30Engine` provides the integration API used by the UI/engine layer.

### Important compatibility note
This milestone does **not** claim a complete proprietary KORG PCM/KMP decoder. The existing KMP inspector remains heuristic until the byte layout is validated against multiple known-good KMP/PCM pairs. The runtime path is ready to consume decoded `SampleData` once the decoder is validated.

### Build
Open the project root in Android Studio and let Gradle sync. No KORG proprietary software or assets are included.
