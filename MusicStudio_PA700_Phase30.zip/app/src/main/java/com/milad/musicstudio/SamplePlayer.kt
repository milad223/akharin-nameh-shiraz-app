package com.milad.musicstudio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.milad.musicstudio.korg.SampleData
import com.milad.musicstudio.korg.SampleZone
import kotlin.math.pow

class SamplePlayer {
    private var track: AudioTrack? = null

    fun play(sample: SampleData) = playZone(sample, 60, 60)

    fun playZone(zone: SampleZone, midiKey: Int, velocity: Int) {
        val semitones = midiKey - zone.rootKey
        val ratio = 2.0.pow(semitones / 12.0)
        val src = zone.sample.pcm
        if (src.isEmpty()) return
        val outFrames = (src.size / zone.sample.channels / ratio).toInt().coerceAtLeast(1)
        val out = ShortArray(outFrames * zone.sample.channels)
        for (i in 0 until outFrames) {
            val pos = i * ratio
            val base = pos.toInt().coerceIn(0, src.size / zone.sample.channels - 1)
            val next = (base + 1).coerceAtMost(src.size / zone.sample.channels - 1)
            val frac = pos - base
            for (ch in 0 until zone.sample.channels) {
                val a = src[base * zone.sample.channels + ch].toInt()
                val b = src[next * zone.sample.channels + ch].toInt()
                val v = (a + (b - a) * frac).toInt()
                out[i * zone.sample.channels + ch] = (v * (velocity.coerceIn(1,127) / 127.0)).toInt().coerceIn(-32768,32767).toShort()
            }
        }
        playRaw(out, zone.sample.sampleRate, zone.sample.channels)
    }

    private fun playRaw(pcm: ShortArray, rate: Int, channels: Int) {
        stop()
        val mask = if (channels == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask).build())
            .setBufferSizeInBytes(maxOf(min, pcm.size * 2))
            .setTransferMode(AudioTrack.MODE_STATIC).build()
        track!!.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)
        track!!.play()
    }

    fun stop() { track?.let { runCatching { it.stop() }; it.release() }; track = null }
}
