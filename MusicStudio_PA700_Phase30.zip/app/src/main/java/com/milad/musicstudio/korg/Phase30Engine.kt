package com.milad.musicstudio.korg

/** Integration layer: KMP-derived zones -> decoded SampleData -> key/velocity selection. */
class Phase30Engine(private val multisample: Multisample) {
    fun trigger(midiKey: Int, velocity: Int): SampleZone? = multisample.select(midiKey, velocity)
    fun zoneCount(): Int = multisample.all().size
}
