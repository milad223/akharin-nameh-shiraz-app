package com.milad.musicstudio.korg

data class SampleZone(
    val lowKey: Int,
    val highKey: Int,
    val rootKey: Int,
    val velocityLow: Int = 1,
    val velocityHigh: Int = 127,
    val sample: SampleData,
    val label: String = ""
) {
    fun accepts(key: Int, velocity: Int): Boolean =
        key in lowKey..highKey && velocity in velocityLow..velocityHigh
}

class Multisample(private val zones: List<SampleZone>) {
    fun select(key: Int, velocity: Int): SampleZone? = zones
        .asSequence()
        .filter { it.accepts(key, velocity) }
        .minByOrNull { kotlin.math.abs(key - it.rootKey) }

    fun all(): List<SampleZone> = zones
}
