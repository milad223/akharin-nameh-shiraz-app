package com.milad.musicstudio.korg

/**
 * Bridges heuristic KMP zones to a PCM catalog using observable IDs/names.
 * No byte layout is presented as an official KORG specification.
 */
data class ResolvedZone(val zone:KmpZone, val sample:PcmEntry?, val confidence:String, val reason:String)

object KmpRuntimeResolver {
    fun resolve(report:KmpReport, catalog:List<PcmEntry>):List<ResolvedZone> {
        return report.zones.map { z ->
            val key = z.name?.trim()?.lowercase()
            val hit = if(key.isNullOrBlank()) null else catalog.firstOrNull { e -> e.id.lowercase().contains(key) }
            if(hit!=null) ResolvedZone(z,hit,"name-match","KMP name candidate matched PCM filename/ID")
            else ResolvedZone(z,null,"unresolved","No deterministic PCM filename/ID match")
        }
    }
}
