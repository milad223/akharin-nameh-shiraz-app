package com.milad.musicstudio.korg

import java.io.File

/** Indexes PCM files/records without assuming a proprietary codec. */
data class PcmEntry(val id:String, val file:File, val recordIndex:Int = -1, val offset:Long = 0L, val bytes:Long = 0L)

object PcmCatalog {
    fun index(files: List<File>): List<PcmEntry> {
        val out=mutableListOf<PcmEntry>()
        files.forEach { f ->
            if (!f.isFile) return@forEach
            if (f.extension.equals("pcm", true)) {
                val rows=runCatching { PcmExtractor.scan(f) }.getOrDefault(emptyList())
                if(rows.isEmpty()) out += PcmEntry(f.name,f,bytes=f.length())
                else rows.forEach { r -> out += PcmEntry("${f.name}#${r.index}",f,r.index,r.dataOffset,r.payloadBytes.toLong()) }
            }
        }
        return out
    }
}
