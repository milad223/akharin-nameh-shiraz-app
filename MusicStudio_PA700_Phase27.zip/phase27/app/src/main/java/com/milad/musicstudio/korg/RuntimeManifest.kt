package com.milad.musicstudio.korg

/** Human-readable runtime plan produced after KMP + PCM inspection. */
data class RuntimeManifest(val zones:List<ResolvedZone>) {
    fun summary():String = buildString {
        append("RUNTIME MAP\n")
        append("zones=${zones.size}\n")
        zones.take(120).forEachIndexed { i,z ->
            append("#${i+1} low=${z.zone.low} high=${z.zone.high} root=${z.zone.root} -> ")
            append(z.sample?.id ?: "UNRESOLVED")
            append(" [${z.confidence}]\n")
        }
        append("\nUnresolved zones remain available for manual/validated mapping.")
    }
}
