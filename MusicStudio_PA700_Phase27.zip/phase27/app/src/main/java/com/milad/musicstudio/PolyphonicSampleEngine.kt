package com.milad.musicstudio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.milad.musicstudio.korg.MultisampleRuntime
import com.milad.musicstudio.korg.SampleData

/** Lightweight Phase-26 sample voice renderer. It resamples decoded 16-bit mono/stereo PCM
 * to the requested pitch and mixes short-lived voices into one AudioTrack stream. */
class PolyphonicSampleEngine {
    private val sampleRate = 44100
    private var track: AudioTrack? = null

    fun start() {
        if (track != null) return
        val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, sampleRate / 4 * 2))
            .setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
    }

    fun play(runtime: MultisampleRuntime, key: Int, velocity: Int = 100, durationMs: Int = 900) {
        val selected = runtime.select(key, velocity) ?: return
        val src = selected.runtime.sample
        val pcm = render(src, selected.pitchRatio, durationMs)
        start()
        track?.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)
    }

    private fun render(src: SampleData, ratio: Double, durationMs: Int): ShortArray {
        val inPcm = src.pcm
        if (inPcm.isEmpty()) return ShortArray(0)
        val frames = minOf(inPcm.size, ((src.sampleRate * durationMs) / 1000).coerceAtLeast(1))
        val outFrames = ((frames / ratio).toInt()).coerceAtLeast(1)
        val out = ShortArray(outFrames)
        for (i in out.indices) {
            val pos = i * ratio
            val idx = pos.toInt().coerceIn(0, frames - 1)
            val next = (idx + 1).coerceAtMost(frames - 1)
            val frac = pos - idx
            val a = inPcm[idx].toInt()
            val b = inPcm[next].toInt()
            val env = if (i < sampleRate * .008) i.toDouble() / (sampleRate * .008) else kotlin.math.exp(-2.2 * i / outFrames.toDouble())
            out[i] = ((a + (b - a) * frac) * env).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    fun stop() { runCatching { track?.stop() }; track?.release(); track = null }
}
