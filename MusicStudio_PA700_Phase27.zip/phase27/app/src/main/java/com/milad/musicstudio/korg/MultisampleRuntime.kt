package com.milad.musicstudio.korg

/** Runtime mapping layer between KMP zone candidates and decoded PCM samples. */
data class RuntimeSample(
    val id: String,
    val sample: SampleData,
    val rootKey: Int = 60,
    val lowKey: Int = 0,
    val highKey: Int = 127,
    val velocityLow: Int = 1,
    val velocityHigh: Int = 127
)

data class SelectedSample(val runtime: RuntimeSample, val pitchRatio: Double)

class MultisampleRuntime(private val samples: List<RuntimeSample>) {
    fun select(key: Int, velocity: Int = 100): SelectedSample? {
        val k = key.coerceIn(0, 127)
        val v = velocity.coerceIn(1, 127)
        val candidates = samples.filter { k in it.lowKey..it.highKey && v in it.velocityLow..it.velocityHigh }
        val chosen = candidates.minByOrNull { distanceToCenter(k, it.lowKey, it.highKey) }
            ?: samples.filter { k in it.lowKey..it.highKey }.minByOrNull { distanceToCenter(k, it.lowKey, it.highKey) }
            ?: return null
        val semitones = k - chosen.rootKey
        return SelectedSample(chosen, Math.pow(2.0, semitones / 12.0))
    }

    private fun distanceToCenter(x: Int, low: Int, high: Int): Int {
        val center = (low + high) / 2
        return kotlin.math.abs(x - center)
    }
}
