# Music Studio PA700 — Phase 27

Phase 27 adds a runtime bridge between the observed KMP zone candidates and an indexed PCM catalog.

- `PcmCatalog`: indexes `.PCM` files and observed PCM records.
- `KmpRuntimeResolver`: attempts deterministic name/ID matches and marks unresolved zones explicitly.
- `RuntimeManifest`: produces a readable KMP → PCM runtime map.
- The UI exposes a **Build Runtime Map** action.

Compatibility note: KMP offsets and PCM decoding remain heuristic/experimental. A successful filename/ID match does not prove the underlying KORG reference semantics, and this phase does not claim proprietary PCM codec decoding.
